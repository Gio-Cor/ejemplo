package com.perfulandia.LogisticaEnvios.service;

import org.springframework.stereotype.Service;



@Service
public class RutaService {
    public String obtenerRutaOptima(String origen, String destino) {
        // Simulación de una ruta óptima sin usar APIs externas
        return "Ruta óptima simulada de " + origen + " a " + destino + ": [Punto A -> Punto B -> Punto C]";
    }
}
