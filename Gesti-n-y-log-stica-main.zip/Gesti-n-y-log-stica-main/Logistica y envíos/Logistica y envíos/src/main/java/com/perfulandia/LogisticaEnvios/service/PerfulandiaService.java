package com.perfulandia.LogisticaEnvios.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.perfulandia.LogisticaEnvios.model.Perfulandia;
import com.perfulandia.LogisticaEnvios.repository.PerfulandiaRepository;

import jakarta.transaction.Transactional;


@Service
@Transactional

public class PerfulandiaService {
    @Autowired
    private PerfulandiaRepository perfulandiaRepository;

    public List<Perfulandia> listarEnvios(){
        return perfulandiaRepository.findAll();


    }

    public Perfulandia agregarEnvio(Perfulandia perfulandia){
        return perfulandiaRepository.save(perfulandia);
    }


    public Perfulandia buscarEnvioId(int id){
        Optional<Perfulandia> envio = perfulandiaRepository.findById(id);
        return envio.orElse(null);

    }


    public Perfulandia actualizarEnvio(Perfulandia envio){
        return perfulandiaRepository.save(envio);
    }


    public String eliminarEnvio(int id){

        if(perfulandiaRepository.existsById(id)){
          perfulandiaRepository.deleteById(id);
          return "ENVÍO ELIMINADO";
        }

        return "NO SE ENCOTRO ENVÍO";

    }

    


    public int totalEnvios(){
        return (int)perfulandiaRepository.count();
    }

    


}
