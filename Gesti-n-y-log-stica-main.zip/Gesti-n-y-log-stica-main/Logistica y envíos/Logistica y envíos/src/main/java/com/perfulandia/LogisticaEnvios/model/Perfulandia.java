package com.perfulandia.LogisticaEnvios.model;
import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="envios")
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Perfulandia {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable=false)
    private int ordenId;

    @Column(unique=true, length=15 , nullable=false)
    private String direccionEntrega;

    @Column(nullable=true)
    private  LocalDate fechaEnvio;

    @Column(nullable=false)
    private String estado; 

    @Column(nullable=true)
    private String ubicacionActual;

    @Column(nullable=false)
    private String origen;

    @Column(nullable=false)
    private String destino;



    

}
