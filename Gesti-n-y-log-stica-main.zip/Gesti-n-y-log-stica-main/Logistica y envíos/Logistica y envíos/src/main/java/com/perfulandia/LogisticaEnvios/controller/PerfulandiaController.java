package com.perfulandia.LogisticaEnvios.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.HttpStatus;

import com.perfulandia.LogisticaEnvios.model.Perfulandia;
import com.perfulandia.LogisticaEnvios.model.RutaRequest;
import com.perfulandia.LogisticaEnvios.service.PerfulandiaService;
import com.perfulandia.LogisticaEnvios.service.RutaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;


/**
 * Controlador REST para la gestión de envíos en Perfulandia.
 */

@RestController
@RequestMapping("/api/v1/perfulandia")
@Tag(name = "Gestión de Envíos", description = "Operaciones CRUD para envíos")

public class PerfulandiaController {
    @Autowired
    private PerfulandiaService perfulandiaService;

    @GetMapping
    @Operation(summary = "Obtener todos los envíos")
    public ResponseEntity<List<Perfulandia>> listar(){
        List<Perfulandia> envios = perfulandiaService.listarEnvios();
        if(envios.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(envios);

      
    }

    

    @PostMapping
    @Operation(summary = "Agregar un nuevo envío")
    public ResponseEntity <?>agregarEnvio(@RequestBody Perfulandia perfulandia){
        try {
            Perfulandia agregarEnvio = perfulandiaService.agregarEnvio(perfulandia);
            return ResponseEntity.ok(agregarEnvio);
        } catch (Exception e) {
            e.printStackTrace(); //Esto mostrara el error en la consola
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
        
        
    }



    @Autowired
    private RutaService rutaService;

    @PostMapping("/optimizar-ruta")
    @Operation(summary = "Optimizar ruta entre dos puntos")
    public ResponseEntity<String> optimizarRuta(@RequestBody RutaRequest request) {
        String resultado = rutaService.obtenerRutaOptima(request.getOrigen(), request.getDestino());
        return ResponseEntity.ok(resultado);
}

    
    
    @GetMapping("/{id}")
    @Operation(summary = "Buscar un envío por ID de orden")
    public ResponseEntity<Perfulandia> buscarOrdenId(@PathVariable int id) {
        Perfulandia envio = perfulandiaService.buscarEnvioId(id);
        if(envio != null){
            return ResponseEntity.ok(envio);
        }else{
            return ResponseEntity.notFound().build();
        }
    }


    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un envío")
    public ResponseEntity<Perfulandia> actualizarEnvio(@PathVariable int id, @RequestBody Perfulandia perfulandia) {
        try {
            Perfulandia update = perfulandiaService.buscarEnvioId(id);
            if(update == null){
                return ResponseEntity.notFound().build();
            }

            //Actualizar datos
            
            update.setId(id);
            update.setOrdenId(perfulandia.getOrdenId());
            update.setDireccionEntrega(perfulandia.getDireccionEntrega());
            update.setFechaEnvio(perfulandia.getFechaEnvio());
            update.setEstado(perfulandia.getEstado());

            //Guardar cambios
            Perfulandia actualizar = perfulandiaService.actualizarEnvio(update);
            return ResponseEntity.ok(actualizar);

        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).build(); //500 Internal server error 
        }
        
    
    }




    @PutMapping("/{id}/seguimiento")
    @Operation(summary = "Actualizar el estado y ubicación de un envío en tiempo real")
    public ResponseEntity<Perfulandia> actualizarSeguimiento(
        @PathVariable int id,
        @RequestBody Map<String, String> seguimiento) {
        Perfulandia envio = perfulandiaService.buscarEnvioId(id);
        if (envio == null) {
            return ResponseEntity.notFound().build();
        }
        if (seguimiento.containsKey("estado")) {
        envio.setEstado(seguimiento.get("estado"));
        }
        if (seguimiento.containsKey("ubicacionActual")) {
        envio.setUbicacionActual(seguimiento.get("ubicacionActual"));
        }
        Perfulandia actualizado = perfulandiaService.actualizarEnvio(envio);
            return ResponseEntity.ok(actualizado);
    }

    @DeleteMapping("/{id}") 
    @Operation(summary = "Eliminar un envío por ID")
    public ResponseEntity<String> eliminarEnvio(@PathVariable int id){
        String resultado = perfulandiaService.eliminarEnvio(id);
        if(resultado.contains("ELIIMINADO")){
            return ResponseEntity.ok(resultado);
        }else{
            return ResponseEntity.status(404).body("NO SE ENCONTRO ENVÍO CON ID "+id);
        }
    }



    


    
    

    

   
    
}
