package com.perfulandia.LogisticaEnvios.repository;


import org.springframework.stereotype.Repository;

import com.perfulandia.LogisticaEnvios.model.Perfulandia;
import org.springframework.data.jpa.repository.JpaRepository;


@Repository

public interface PerfulandiaRepository extends JpaRepository<Perfulandia, Integer> {


     

    
}





    






























