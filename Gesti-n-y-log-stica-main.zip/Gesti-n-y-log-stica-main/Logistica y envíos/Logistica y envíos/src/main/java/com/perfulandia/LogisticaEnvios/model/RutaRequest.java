package com.perfulandia.LogisticaEnvios.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RutaRequest {
    
    private String origen;
    private String destino;

}
